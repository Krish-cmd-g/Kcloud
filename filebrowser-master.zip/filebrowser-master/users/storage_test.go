package users

// Interface is implemented by storage
var _ Store = &Storage{}
